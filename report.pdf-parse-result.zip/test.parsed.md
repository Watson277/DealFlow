# PDF 解析结果：test.pdf

- Document ID：`9da933a1-0151-54fd-87f1-a55243bbe8dd`
- Parser：`page-routing-layout-2.1`
- Document Type：`mixed`
- Page Count：`10`

--- Page 1 ---
DiffGraph: Heterogeneous Graph Diffusion Model

docker compose up -d --force-recreate api rfp-worker WSDM-2025

Zongwei Li, Lianghao Xia, Hua Hua, Shijie Zhang, Shuangyang Wang, Chao Huang University of Hong Kong, Hong Kong, China. Tencent, Shenzhen, Guangdong, China

--- Page 2 ---
Motivation

动机：

主要方法：

用扩散模型（Diffusion Model）在“隐空间”
中对异构图进行逐步去噪与语义迁移

从“辅助异构图”中提取对目标任务最有
用的语义信息，并去除噪声。

| 模块 | 作用 |
| --- | --- |
| 目标图 Gₜ | 任务相关关系（如购买） |
| 辅助图 Gₛ | 其他行为/关系 |
| 潜空间扩散 | 在 embedding 空间中逐步加噪 + 去噪 |
| 语义迁移 | 把辅助图语义映射到目标语义空间 |

--- Page 3 ---
Overview of DiffGraph

Fe

1 Weight，

1/_ a1 &

s(t =) Cn Sequence!

@e |如bpr + Last

ght

J (Sit

& we

Recommendation _) seme.三二

— es ae

u es x -

国原一>

===:

=

t eaoroee

= =

i132

Z

1

y

己

E,

ml ------4--

V

a 2N]6

| Loce +L, |= == SF一Loss |

ES

Classification

Hy Hy ¢和

H' 0

Forward Process

— Process

ee

i

:

' Fuse

pune aa

il

z= = =

oo)

+ Ag+四

|

a

4

Na»

q(At | Ae

i lL gw UX

ene

wT}

! Step

H Sie Embed. = oe = oar Ho;

“!

Heterogeneous representation; ~—~/*40-—~/4"1 SUH 2

Heterogeneous Graphs

Graph Embedding Learning

Heterogeneous Relation Diffusion

Figure 1: Overall architecture of the proposed DiffGraph framework.

Proposed DiffGraph consists of three modules: the Graph Embedding learning, Model Optimization
Objectives and the Heterogeneous Relation Diffusion.

Proposed DiffGraph consists of three modules: the Graph Embedding learning, Model Optimization

Objectives and the Heterogeneous Relation Diffusion.

--- Page 4 ---
Heterogenous Graph Learning

目标：学习各异构关系的结构语义，得到初始节点embedding

Motivated by the simplicity and effectiveness of Graph Convolutional Networks (GCNs) [12], our DiffGraph adopts a GCN-based encoding process for Enc(-), which is formally defined as follows:

| b= LZ: 5 1 4 1 1 3 292 497 89 46 11.201363 Save 2 1 5 0 0 0 2 550 967 2 -1 3 1 5 1 0 0 2 550 967 2 -1 4 1 5 1 1 0 2 550 967 2 -1 5 1 5 1 1 1 2 550 967 2 95.000000 2 1 6 0 0 0 968 2 1 550 -1 3 1 6 1 0 0 968 2 1 550 -1 4 1 6 1 1 0 968 2 1 550 -1 5 1 6 1 1 1 968 2 1 550 95.000000 |
| --- |
|  |
| wt x git Foo fo a oO + Aeterogeneous representation Graph Embedding Learning |

| E = Pooling({E;\|r € E}), |  |
| --- | --- |
| E,j = norm(5(D~!/2A'T | 2B 1)) |

where Ar € R!V!*!V! denotes the specific adjacency matrix for

each heterogeneous relation r € E, and D denotes its corresponding

diagonal degree matrix. E,) € R'V|*4 represents the embedding

matrix at the /-th GCN iteration. For datasets without node features, the initial embeddings E,9 are randomly initialized learnable parameters. 层间传播->多关系融合 BM: 、 。 norm: LayerNorm 。 o:非线性激活(ReLU)

。 E,o:初始特征

。五/):在关系上上聚合第|跳邻居后的embedding

--- Page 5 ---
Core Methodology

目标图(Target Relation) 与辅助图(Auxiliary Relation) 拆分

论文的最终优化目标

核心思想

在基于图的任务学习中，Graph Encoder的作用是聚合相邻节点的Embedding，将图的结构语义转换为Latent Space中
的低维信息。这一特点表明，通过在Latent Space内学习去噪过程𝜑‘，我们的Latent Space Diff Model可以有效地过滤
异构图中不精确的语义，从而更好地支持目标图的学习。

--- Page 6 ---
Forward Process

逐渐加入高斯噪声

最终变成纯噪声

噪声调度，决定每一步加多少噪声、保留多少语义，
以及模型如何在不同噪声强度下学习语义对齐

--- Page 7 ---
Reverse Process

目标：去噪并对齐到目标语义反扩散模型其中： 特点：


共享MLP，所有t复用


s_t：时间步嵌入（指示噪声水平）

--- Page 8 ---
Loss Function


加权的L2-MSE（均方误差）损失：

在确定步数𝑡时，采用统一的抽样策略。形式上，扩散损失L_𝑑𝑒𝑛𝑜如下

模型要学会把noisy embedding 还原成
clean embedding。


权重来自扩散模型的概率推导（ELBO 变分下界）

对从[1,T]区间随机均匀采样得到的时间步t 取期望，关注的是噪声随机性


不同时间步的重要性不同，小t的噪声少易还原，
大t噪声多不易还原，权重会自动调节不同t 的
训练强度。

对噪声样本ℎ௧取期望，关注的是不同噪声强度阶段。

--- Page 9 ---
Downstream tasks

Link Prediction

(1)对一条候选边（u, v），用点积作为打分。直观
上：embedding 越相似（点积越大），越可能有链
接/交互。
损失函数为经典的BPR loss（pairwise ranking）。
正样本𝑣+（真实发生过目标行为）
负样本𝑣−（没发生过目标行为）
学一个排序函数，把正交互排到负交互前面。

Node Prediction

--- Page 10 ---
Experiments

Node Classification performance on public datasets

Recall@20

| Metric |  | GraphSage | GAE | Mp2vec | HERec | HetGNN | HAN | DGI | DMGI | HeCo | GraphMAE |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Micro-F1 | 20 60 | 71.44+8.7 73.61+8.6 74.05+8.3 | 91.55+0.1 90.00+0.3 90.95+0.2 | 89.67+0.1 89.14+0.2 89.14+0.2 | 90.24+0.4 90.15+0.4 91.01+0.3 | 90.11+1.0 89.03+0.7 90.43+0.6 | 90.16+0.9 89.47+0.9 90.34+0.8 | 88.72+2.6 89.22+0.5 90.35+0.8 | 90.78+0.3 89.92+0.4 90.66+0.5 | 91.9740.2 90.76+0.3 91.59+0.2 | 89.31+0.7 87.80+0.5 89.82+0.4 |
| Macro-F1 | 20 40 60 | 71.9748.4 73.6948.4 73.8648.1 | 90.90+0.1 89.60+0.3 90.08+0.2 | 88.98+0.2 88.68+0.2 90.25+0.1 | 89.57+0.4 89.73+0.4 90.18+0.3 | 89.51+1.1 88.61+0.8 89.56+0.5 | 89.31+0.9 88.87+1.0 89.20+0.8 | 87.93+2.4 88.62+0.6 89.19+0.9 | 89.94+0.4 89.25+0.4 89.46+0.6 | 91.28+0.2 90.34+0.3 90.64+0.3 | 87.94+0.7 86.85+0.7 88.07+0.6 |
| Auc | 20 40 60 | 90.59+4.3 91.42+4.0 91.73+3.8 | 98.15+0.1 97.85+0.1 98.37+0.1 | 97.69+0.0 97.08+0.0 98.00+0.0 | 98.21+0.2 97.93+0.1 98.49+0.1 | 97.96+0.4 97.70+0.3 97.97+0.2 | 98.07+0.6 97.48+0.6 97.96+0.5 | 96.99+1.4 97.12+0.4 97.76+0.5 | 97.75+0.3 97.23+0.2 97.72+0.4 | 98.32+0.1 98.06+0.1 98.59+0.1 | 92.23+3.0 91.7642.5 91.63+2.5 |
| Micro-F1 | 20 40 60 | 49.68+3.1 52.10+2.2 51.36+2.2 | 65.78+2.9 71.3441.8 67.70+1.9 | 60.82+0.4 69.66+0.6 63.92+0.5 | 63.64+1.1 71.5740.7 69.76+0.8 | 61.49+2.5 68.47+2.2 65.6142.2 | 68.86+4.6 76.89+1.6 74.73+1.4 | 62.39+3.9 63.8742.9 63.10+3.0 | 63.93+3.3 63.60+2.5 62.51+2.6 | 78.81+1.3 80.53+0.7 82.46+1.4 | 68.21+0.3 74.2340.2 72.28+0.2 |
| Macro-F1 | 20 40 60 | 42.46+2.5 45.7741.5 44.9142.0 | 60.22+2.0 65.66+1.5 63.74+1.6 | 54.78+0.5 64.77+0.5 60.65+0.3 | 58.32+1.1 64.50+0.7 65.53+0.7 | 50.06+0.9 58.97+0.9 57.34+1.4 | 56.07+3.2 63.85+1.5 62.02+1.2 | 51.61+3.2 54.72+2.6 55.45土2.4 | 59.50+2.1 61.92+2.1 61.1542.5 | 71.3841.1 73.75+0.5 75.8041.8 | 62.64+0.2 68.17+0.2 68.21+0.2 |
| Auc | 20 40 60 | 70.86+2.5 74.44+1.3 74.16+1.3 | 85.39+1.0 88.29+1.0 86.92+0.8 | 81.22+0.3 88.82+0.2 85.57+0.2 | 83.35+0.5 88.70+0.4 87.74+0.5 | 77.9641.4 83.14+1.6 84.77+0.9 | 78.92+2.3 80.72+2.1 80.39+1.5 | 75.89+2.2 77.8642.1 77.2141.4 | 85.34+0.9 88.02+1.3 86.20+1.7 | 90.82+0.6 92.11+0.6 92.40+0.7 | 86.29+4.1 89.98+0.0 88.32+0.0 |

Link Prediction Performance on Public Datasets

(c) JCAI-Recall

|  |  | Pin: | age | NG | CF |  |  |  |  |  |  |  |  | DiffC | raph |  | TOV |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| R@20 | N@20 | R@20 | N@20 | R@20 | N@20 | R@20 | N@20 | R@20 | N@20 | R@20 | N@20 | R@20 | N@20 | R@20 | N@20 | RQO20 | N@20 | R@20 |
| 0.0248 | 0.0131 | 0.0368 | 0.0156 | 0.0399 | 0.0169 | 0.0441 | 0.0192 | 0.0419 | 0.0179 | 0.0431 | 0.0192 | 0.0463 | 0.0197 | 0.0589 | 0.0274 | 27.21% | 39.09% | 9.8-10 |
| 0.0308 | 0.0237 | 0.0423 | 0.0248 | 0.0405 | 0.0257 | 0.0460 | 0.0265 | 0.0492 | 0.0258 | 0.0413 | 0.0250 | 0.0524 | 0.0302 | 0.0620 | 0.0367 | 18.32% | 21.52% | 1.65-9 |
| 0.0051 | 0.0037 | 0.0101 | 0.0041 | 0.0091 | 0.0035 | 0.0108 | 0.0048 | 0.0112 | 0.0045 | 0.0126 | 0.0051 | 0.0136 | 0.0054 | 0.0171 | 0.0063 | 25.74% | 16.67% | 3.1-11 |

(a) Tmall-Recall

0.065

0.060

Recall@20

0.055

0.050 i

z=

0.045 -CO -D iam -u Co -| & ours

0.040 —— Lett (b) Rocket-Recall

0.020

Recall@20

eA

|

Ea

o eo

So oO

& 5

Ablation Study
-D：省略整体扩散模块
-U：忽略推荐数据的用户类信息
-I：类似于-U，消除物品类信息

Ablation Study

-D:省略整体扩散模块

二忽略推荐数据的用户类信息

:类似于-U，消除物品类信息
